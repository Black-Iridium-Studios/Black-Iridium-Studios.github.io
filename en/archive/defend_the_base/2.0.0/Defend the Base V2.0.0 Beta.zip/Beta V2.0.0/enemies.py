import pygame

pygame.init()


class Infantry:
    def __init__(self, surface, x, y, hp, speed, direction):
        self.x = x
        self.y = y
        self.surface = surface
        self.hp = hp
        self.speed = speed
        self.draw_count = 0
        self.direction = direction
        self.reward = 15
        self.damage = 5

    def draw(self):
        if self.direction == "up":
            self.y -= self.speed
            image_rotation = 0
        elif self.direction == "down":
            self.y += self.speed
            image_rotation = 180
        elif self.direction == "left":
            self.x -= self.speed
            image_rotation = 90
        elif self.direction == "right":
            self.x += self.speed
            image_rotation = 270

        if self.draw_count <= 5:
            self.surface.blit(pygame.transform.rotate(pygame.transform.scale(pygame.image.load("textures/infantry_0.png").convert_alpha(), (90, 90)), image_rotation), (self.x - 45, self.y - 45))
            self.draw_count += 1
        elif self.draw_count >= 6:
            self.surface.blit(pygame.transform.rotate(pygame.transform.scale(pygame.image.load("textures/infantry_0.png").convert_alpha(), (90, 90)), image_rotation), (self.x - 45, self.y - 45))
            self.draw_count += 1
        if self.draw_count >= 10:
            self.draw_count = 0

class Tank:
    def __init__(self, surface, x, y, hp, speed, direction):
        self.x = x
        self.y = y
        self.surface = surface
        self.hp = hp
        self.speed = speed
        self.draw_count = 0
        self.direction = direction
        self.reward = 30
        self.damage = 10

    def draw(self):
        if self.direction == "up":
            self.y -= self.speed
            image_rotation = 0
        elif self.direction == "down":
            self.y += self.speed
            image_rotation = 180
        elif self.direction == "left":
            self.x -= self.speed
            image_rotation = 90
        elif self.direction == "right":
            self.x += self.speed
            image_rotation = 270

        if self.draw_count <= 5:
            self.surface.blit(pygame.transform.rotate(pygame.transform.scale(pygame.image.load("textures/tank_0.png").convert_alpha(), (80, 80)), image_rotation), (self.x - 40, self.y - 40))
            self.draw_count += 1
        elif self.draw_count >= 6:
            self.surface.blit(pygame.transform.rotate(pygame.transform.scale(pygame.image.load("textures/tank_1.png").convert_alpha(), (80, 80)), image_rotation), (self.x - 40, self.y - 40))
            self.draw_count += 1
        if self.draw_count >= 10:
            self.draw_count = 0
