import pygame
import csv

pygame.init()


def Translated_text(language, text):
    for line in open(f"languages/{language}.language").readlines():
        if line.split("=")[0] == text:
            return line.split("=")[1][:-1]


def Settings(setting):
    for line in open("settings.data").readlines():
        if line.startswith(setting):
            return line.split("=")[1][:-1]


def GetLevelData(level, difficulty):
    level_data = []

    for i in range(12):
        row = [0] * 19
        level_data.append(row)

    with open(f"{level}.lvl_map", newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter= ',')
        for x, row in enumerate(reader):
            for y, tile in enumerate(row):
                level_data[x][y] = int(tile)

    spawnY = 0

    for row in level_data:
        if row[18] == 21:
            spawnY = level_data.index(row)

    path_raw = [[spawnY, 18, "left"]]

    while True:
        if level_data[path_raw[-1][0]][path_raw[-1][1]] == 21:
            if path_raw[-1][2] == "left":
                if path_raw[-1][1] == 0:
                    break

                elif level_data[path_raw[-1][0]][path_raw[-1][1] - 1] == 21:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] - 1, "left"])

                elif level_data[path_raw[-1][0]][path_raw[-1][1] - 1] == 12:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] - 1, "down"])

                elif level_data[path_raw[-1][0]][path_raw[-1][1] - 1] == 14:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] - 1, "up"])

            elif path_raw[-1][2] == "right":
                if level_data[path_raw[-1][0]][path_raw[-1][1] + 1] == 21:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] + 1, "right"])

                elif level_data[path_raw[-1][0]][path_raw[-1][1] + 1] == 13:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] + 1, "down"])

                elif level_data[path_raw[-1][0]][path_raw[-1][1] + 1] == 15:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] + 1, "up"])

        elif level_data[path_raw[-1][0]][path_raw[-1][1]] == 20:
            if path_raw[-1][2] == "down":
                if level_data[path_raw[-1][0] + 1][path_raw[-1][1]] == 20:
                    path_raw.append([path_raw[-1][0] + 1, path_raw[-1][1], "down"])

                elif level_data[path_raw[-1][0] + 1][path_raw[-1][1]] == 14:
                    path_raw.append([path_raw[-1][0] + 1, path_raw[-1][1], "right"])

                elif level_data[path_raw[-1][0] + 1][path_raw[-1][1]] == 15:
                    path_raw.append([path_raw[-1][0] + 1, path_raw[-1][1], "left"])

            elif path_raw[-1][2] == "up":
                if level_data[path_raw[-1][0] - 1][path_raw[-1][1]] == 20:
                    path_raw.append([path_raw[-1][0] - 1, path_raw[-1][1], "up"])

                elif level_data[path_raw[-1][0] - 1][path_raw[-1][1]] == 12:
                    path_raw.append([path_raw[-1][0] - 1, path_raw[-1][1], "right"])

                elif level_data[path_raw[-1][0] - 1][path_raw[-1][1]] == 13:
                    path_raw.append([path_raw[-1][0] - 1, path_raw[-1][1], "left"])

        elif level_data[path_raw[-1][0]][path_raw[-1][1]] == 12:
            if path_raw[-1][2] == "right":
                if level_data[path_raw[-1][0]][path_raw[-1][1] + 1] == 21:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] + 1, "right"])

                elif level_data[path_raw[-1][0]][path_raw[-1][1] + 1] == 13:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] + 1, "down"])

                elif level_data[path_raw[-1][0]][path_raw[-1][1] + 1] == 15:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] + 1, "up"])

            elif path_raw[-1][2] == "down":
                if level_data[path_raw[-1][0] + 1][path_raw[-1][1]] == 20:
                    path_raw.append([path_raw[-1][0] + 1, path_raw[-1][1], "down"])

                elif level_data[path_raw[-1][0] + 1][path_raw[-1][1]] == 14:
                    path_raw.append([path_raw[-1][0] + 1, path_raw[-1][1], "right"])

                elif level_data[path_raw[-1][0] + 1][path_raw[-1][1]] == 15:
                    path_raw.append([path_raw[-1][0] + 1, path_raw[-1][1], "left"])

        elif level_data[path_raw[-1][0]][path_raw[-1][1]] == 13:
            if path_raw[-1][2] == "left":
                if level_data[path_raw[-1][0]][path_raw[-1][1] - 1] == 21:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] - 1, "left"])

                elif level_data[path_raw[-1][0]][path_raw[-1][1] - 1] == 12:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] - 1, "down"])

                elif level_data[path_raw[-1][0] + 1][path_raw[-1][1]] == 14:
                    path_raw.append([path_raw[-1][0] + 1, path_raw[-1][1], "up"])

            elif path_raw[-1][2] == "down":
                if level_data[path_raw[-1][0] + 1][path_raw[-1][1]] == 20:
                    path_raw.append([path_raw[-1][0] + 1, path_raw[-1][1], "down"])

                elif level_data[path_raw[-1][0] + 1][path_raw[-1][1]] == 14:
                    path_raw.append([path_raw[-1][0] + 1, path_raw[-1][1], "right"])

                elif level_data[path_raw[-1][0] + 1][path_raw[-1][1]] == 15:
                    path_raw.append([path_raw[-1][0] + 1, path_raw[-1][1], "left"])

        elif level_data[path_raw[-1][0]][path_raw[-1][1]] == 14:
            if path_raw[-1][2] == "right":
                if level_data[path_raw[-1][0]][path_raw[-1][1] + 1] == 21:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] + 1, "right"])

                elif level_data[path_raw[-1][0]][path_raw[-1][1] + 1] == 13:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] + 1, "down"])

                elif level_data[path_raw[-1][0] + 1][path_raw[-1][1]] == 15:
                    path_raw.append([path_raw[-1][0] + 1, path_raw[-1][1], "left"])

            elif path_raw[-1][2] == "up":
                if level_data[path_raw[-1][0] - 1][path_raw[-1][1]] == 20:
                    path_raw.append([path_raw[-1][0] - 1, path_raw[-1][1], "up"])

                elif level_data[path_raw[-1][0] - 1][path_raw[-1][1]] == 12:
                    path_raw.append([path_raw[-1][0] - 1, path_raw[-1][1], "right"])

                elif level_data[path_raw[-1][0] - 1][path_raw[-1][1]] == 13:
                    path_raw.append([path_raw[-1][0] - 1, path_raw[-1][1], "left"])

        elif level_data[path_raw[-1][0]][path_raw[-1][1]] == 15:
            if path_raw[-1][2] == "left":
                if level_data[path_raw[-1][0]][path_raw[-1][1] - 1] == 21:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] - 1, "left"])

                elif level_data[path_raw[-1][0]][path_raw[-1][1] - 1] == 12:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] - 1, "down"])

                elif level_data[path_raw[-1][0]][path_raw[-1][1] - 1] == 14:
                    path_raw.append([path_raw[-1][0], path_raw[-1][1] - 1, "up"])

            elif path_raw[-1][2] == "up":
                if level_data[path_raw[-1][0] - 1][path_raw[-1][1]] == 20:
                    path_raw.append([path_raw[-1][0] - 1, path_raw[-1][1], "up"])

                elif level_data[path_raw[-1][0] - 1][path_raw[-1][1]] == 12:
                    path_raw.append([path_raw[-1][0] - 1, path_raw[-1][1], "right"])

                elif level_data[path_raw[-1][0] - 1][path_raw[-1][1]] == 13:
                    path_raw.append([path_raw[-1][0] - 1, path_raw[-1][1], "left"])

    path = []

    for tile in path_raw:
        if level_data[tile[0]][tile[1]] not in [20, 21]:
            path.append(tile)

    waves = []
    for i in range(10):
        waves.append([])

    with open(f"{level}.lvl_waves_{difficulty}") as csvfile:
        reader = csv.reader(csvfile, delimiter='-')
        for i, wave in enumerate(reader):
            if wave:
                for enemy in wave:
                    waves[i].append((enemy.split(';')[0], int(enemy.split(';')[1])))

    return level_data, spawnY, path, waves


class Button:
    def __init__(self, surface, x, y, width, height, color, text='', font='', text_size=None, text_color=None, outline=None, outline_color=None, image=None, image_size=None, press_effect=None):
        self.surface = surface
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.text = text
        self.text_font = font
        self.text_size = text_size
        self.text_color = text_color
        self.outline = outline
        self.outline_color = outline_color
        self.press_effect = press_effect

        self.image = None

        if image is not None:
            self.image = pygame.transform.scale(image, image_size)
            self.image_size = image_size


    def draw(self):
        if self.outline and self.outline_color:
            pygame.draw.rect(self.surface, self.outline_color, pygame.Rect(self.x - self.width / 2 - self.outline, self.y - self.height / 2 - self.outline, self.width + self.outline * 2, self.height + self.outline * 2))
        pygame.draw.rect(self.surface, self.color, pygame.Rect(self.x - self.width / 2, self.y - self.height / 2, self.width, self.height))

        if self.image is not None:
            self.surface.blit(self.image, (self.x - self.image_size[0] / 2, self.y - self.image_size[1] / 2))

        if self.text != '':
            font = pygame.font.SysFont(self.text_font, self.text_size)
            text = font.render(self.text, 1, self.text_color)
            self.surface.blit(text, (self.x - text.get_width() / 2, self.y - text.get_height() / 2 - self.text_size / 10))

    def click(self):
        mouse = pygame.mouse.get_pos()
        if self.outline is not None:
            if self.x - self.width / 2 - self.outline <= mouse[0] <= self.x + self.width / 2 + self.outline:
                if self.y - self.height / 2 - self.outline <= mouse[1] <= self.y + self.height / 2 + self.outline:
                    return True

        elif self.outline is None:
            if self.x - self.width / 2 <= mouse[0] <= self.x + self.width / 2:
                if self.y - self.height / 2 <= mouse[1] <= self.y + self.height / 2:
                    return True
        else:
            return False


class Tower_menu:
    def __init__(self, surface, x, y, tile_coords):
        self.surface = surface
        self.x = x
        self.y = y
        self.tile_coords = tile_coords
        self.button_images = []
        self.unlocked_towers = 0
        for line in open("upgrades.data").readlines():
            if int(line.split("=")[1].split("\n")[0]) >= 1:
                self.unlocked_towers += 1

    def draw(self):
        self.surface.blit(pygame.image.load("textures/tower_menu.png").convert_alpha(), (self.x - 150, self.y - 150))
        self.surface.blit(pygame.transform.scale(pygame.image.load(f"textures/laser.png").convert_alpha(), (65, 65)), (self.x - 130, self.y - 85))

        if self.unlocked_towers >= 2:
            self.surface.blit(pygame.transform.scale(pygame.image.load(f"textures/auto_base.png").convert_alpha(), (65, 65)), (self.x - 70, self.y - 140))
            self.surface.blit(pygame.transform.scale(pygame.image.load(f"textures/auto_gun_0.png").convert_alpha(), (65, 65)), (self.x - 70, self.y - 140))
        else:
            self.surface.blit(pygame.transform.scale(pygame.image.load(f"textures/locked.png").convert_alpha(), (65, 65)), (self.x - 70, self.y - 140))

        if self.unlocked_towers >= 3:
            self.surface.blit(pygame.transform.scale(pygame.image.load(f"textures/cannon_base.png").convert_alpha(), (65, 65)), (self.x + 5, self.y - 140))
            self.surface.blit(pygame.transform.scale(pygame.image.load(f"textures/cannon_gun.png").convert_alpha(), (65, 65)), (self.x + 5, self.y - 140))
        else:
            self.surface.blit(pygame.transform.scale(pygame.image.load(f"textures/locked.png").convert_alpha(), (65, 65)), (self.x + 5, self.y - 140))

        if self.unlocked_towers >= 4:
            self.surface.blit(pygame.transform.scale(pygame.image.load(f"textures/fire.png").convert_alpha(), (65, 65)), (self.x + 65, self.y - 85))

        else:
            self.surface.blit(pygame.transform.scale(pygame.image.load(f"textures/locked.png").convert_alpha(), (65, 65)), (self.x + 65, self.y - 85))

    def click(self):
        mouse = pygame.mouse.get_pos()

        if Button(self.surface, self.x - 97.5, self.y - 52.5, 65, 65, pygame.Color(88, 88, 88)).click():
            return 1
        if self.unlocked_towers >= 2:
            if Button(self.surface, self.x - 37.5, self.y - 107.5, 65, 65, pygame.Color(88, 88, 88)).click():
                return 2
        if self.unlocked_towers >= 3:
            if Button(self.surface, self.x + 37.5, self.y - 97.5, 65, 65, pygame.Color(88, 88, 88)).click():
                return 3
        if self.unlocked_towers >= 4:
            if Button(self.surface, self.x + 97.5, self.y - 52.5, 65, 65, pygame.Color(88, 88, 88)).click():
                return 4

        elif self.x - 150 <= mouse[0] <= self.x + 150:
            if self.y - 150 <= mouse[1] <= self.y + 27:
                return True


class Upgrade_menu:
    def __init__(self, surface, x, y, tower):
        self.surface = surface
        self.x = x
        self.y = y
        self.tower = tower

    def draw(self):
        self.surface.blit(pygame.image.load("textures/tower_menu.png").convert_alpha(), (self.x - 150, self.y - 150))
        self.surface.blit(pygame.image.load(f"textures/lvl_up.png").convert_alpha(), (self.x - 130, self.y - 85))

    def click(self):
        mouse = pygame.mouse.get_pos()

        if Button(self.surface, self.x - 97.5, self.y - 52.5, 65, 65, pygame.Color(88, 88, 88)).click():
            return 1

        elif Button(self.surface, self.x + 97.5, self.y - 52.5, 65, 65, pygame.Color(88, 88, 88)).click():
            return 2

        elif self.x - 150 <= mouse[0] <= self.x + 150:
            if self.y - 150 <= mouse[1] <= self.y + 27:
                return True


class Chose_menu:
    def __init__(self, surface, title_text, button1_text, button2_text):
        self.surface = surface
        self.buttons = [Button(surface, 1920 / 2, 1080 / 2 - 65, 300, 75, pygame.Color(100, 100, 100), Translated_text(Settings("language"), button1_text), "comicsans", 60, pygame.Color(250, 250, 250), 10, pygame.Color(50, 50, 50)), Button(surface, 1920 / 2, 1080 / 2 + 65, 300, 75, pygame.Color(100, 100, 100), Translated_text(Settings("language"), button2_text), "comicsans", 60, pygame.Color(250, 250, 250), 10, pygame.Color(50, 50, 50))]

        font = pygame.font.SysFont("freesansbold.ttf", 100)
        self.pause_text = font.render(Translated_text(Settings("language"), title_text), 1, pygame.Color("white"))

    def draw(self):
        menu_rect_outline = pygame.Rect(765, 245, 390, 450)
        menu_rect = pygame.Rect(780, 260, 360, 420)

        pygame.draw.rect(self.surface, pygame.Color(100, 100, 100), menu_rect_outline)
        pygame.draw.rect(self.surface, pygame.Color(140, 140, 140), menu_rect)

        self.surface.blit(self.pause_text, (1920 / 2 - self.pause_text.get_width() / 2, 270 + self.pause_text.get_height() / 2))

        for button in self.buttons:
            button.draw()

    def click(self):
        for button in self.buttons:
            if button.click():
                return self.buttons.index(button) + 1

        return False
