import math
import random
import pygame

pygame.init()


global_levels_list = []
for line in open("upgrades.data").readlines():
    global_levels_list.append(line.split("=")[1].split("\n")[0])


class Laser:

    def __init__(self, surface, x, y, level):
        self.surface = surface
        self.x = x
        self.y = y
        self.level = level
        self.range = 180 + level * 45
        self.damage = 4 + 1 * level + float(1.5 * int(global_levels_list[0]) - 1.5)
        self.shot_count = 0
        self.price = 75
        self.upgrade_price = [60, 90, 120]

    def draw(self):
        self.surface.blit(pygame.image.load("textures/laser.png").convert_alpha(), (self.x - 45, self.y - 45))

    def shot(self, enemies_list):
        shot_range = 180 + self.level * 45
        damage = 1.5 + 0.5 * self.level + float(1 * int(global_levels_list[0]) - 1)

        for enemy in enemies_list:
            if -shot_range <= math.sqrt((enemy.x - self.x) ** 2 + (enemy.y - self.y) ** 2) <= shot_range:
                pygame.draw.line(self.surface, pygame.Color(255, 0, 0), (self.x, self.y), (enemy.x, enemy.y), width=5)
                pygame.draw.circle(self.surface, pygame.Color(255, 0, 0), (self.x, self.y), 2)
                pygame.draw.circle(self.surface, pygame.Color(255, 0, 0), (enemy.x, enemy.y), 2)
                if self.shot_count == 40:
                    enemy.hp -= damage
                    self.shot_count = 0

                else:
                    self.shot_count += 1


class Auto:

    def __init__(self, surface, x, y, level):
        self.surface = surface
        self.x = x
        self.y = y
        self.level = level
        self.shot_count = 0
        self.random_shot = (random.randint(-5, 5), random.randint(-5, 5))
        self.price = 150
        self.upgrade_price = [90, 150, 200]

    def draw(self, enemies):
        self.surface.blit(pygame.image.load("textures/auto_base.png").convert_alpha(), (self.x - 45, self.y - 45))

        shot_range = 180 + self.level * 45

        enemies_coords_list = []

        gun_image = pygame.transform.scale(pygame.image.load("textures/auto_gun_0.png").convert_alpha(), (100, 100))

        for enemy in enemies:
            if -shot_range <= math.sqrt((enemy.x - self.x) ** 2 + (enemy.y - self.y) ** 2) <= shot_range:

                enemies_coords_list.append((enemy.x - self.x, enemy.y - self.y))
                enemies_coords_list.sort()

                if str(enemies_coords_list[0][1]).startswith("-"):
                    if enemies_coords_list[0][1] == 0:
                        gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/auto_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), 90)

                    else:
                        gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/auto_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), math.atan(enemies_coords_list[0][0] / enemies_coords_list[0][1]) * 180 / math.pi)

                elif int(enemies_coords_list[0][0]) == 0:
                    gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/auto_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), 180)

                elif int(enemies_coords_list[0][1]) == 0:
                    gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/auto_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), 270)

                else:
                    if str(enemies_coords_list[0][0]).startswith("-"):
                        if str(enemy.y - self.y).startswith("-"):
                            gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/auto_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), math.atan(enemies_coords_list[0][0] / enemies_coords_list[0][1]) * 180 / math.pi + 180)

                        else:
                            gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/auto_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), math.atan(enemies_coords_list[0][0] / enemies_coords_list[0][1]) * 180 / math.pi)

                    else:
                        gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/auto_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), math.atan(enemies_coords_list[0][0] / enemies_coords_list[0][1]) * 180 / math.pi + 180)

        gun_rect = gun_image.get_rect()

        self.surface.blit(gun_image, (self.x - gun_rect.center[0], self.y - gun_rect.center[1]))

    def shot(self, enemies):
        shot_range = 180 + self.level * 45
        damage = 1.5 + 0.5 * self.level + float(1 * int(global_levels_list[0]) - 1)

        in_range_enemies_list = []

        for enemy in enemies:
            if -shot_range <= math.sqrt((enemy.x - self.x) ** 2 + (enemy.y - self.y) ** 2) <= shot_range:

                in_range_enemies_list.append((enemy.x, enemy.y))
                in_range_enemies_list.sort()

        self.shot_count += 1

        if len(in_range_enemies_list) != 0:
            if self.shot_count >= 5:
                pygame.draw.line(self.surface, pygame.Color(237, 166, 43), (self.x, self.y), (in_range_enemies_list[0][0] + self.random_shot[0], in_range_enemies_list[0][1] + self.random_shot[1]))
                for enemy in enemies:
                    if enemy.x == in_range_enemies_list[0][0] and enemy.y == in_range_enemies_list[0][1]:
                        enemy.hp -= damage

        if self.shot_count >= 9:
            self.random_shot = (random.randint(-5, 5), random.randint(-5, 5))
            self.shot_count = 0


class Cannon:

    def __init__(self, surface, x, y, level):
        self.surface = surface
        self.x = x
        self.y = y
        self.level = level
        self.shot_count = 0
        self.price = 250

    def draw(self, enemies):
        self.surface.blit(pygame.image.load("textures/cannon_base.png").convert_alpha(), (self.x - 45, self.y - 45))

        shot_range = 180 + self.level * 45

        enemies_coords_list = []

        gun_image = pygame.transform.scale(pygame.image.load("textures/cannon_gun_0.png").convert_alpha(), (100, 100))

        for enemy in enemies:
            if -shot_range <= math.sqrt((enemy.x - self.x) ** 2 + (enemy.y - self.y) ** 2) <= shot_range:

                enemies_coords_list.append((enemy.x - self.x, enemy.y - self.y))
                enemies_coords_list.sort()

                if str(enemy.y - self.y).startswith("-"):
                    gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/cannon_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), math.atan(enemies_coords_list[0][0] / enemies_coords_list[0][1]) * 180 / math.pi)


                elif int(enemies_coords_list[0][0]) == 0:
                    gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/cannon_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), 90)


                elif int(enemies_coords_list[0][1]) == 0:
                    gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/cannon_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), 0)

                else:
                    gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/cannon_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), math.atan(enemies_coords_list[0][0] / enemies_coords_list[0][1]) * 180 / math.pi + 180)

        gun_rect = gun_image.get_rect()

        self.surface.blit(gun_image, (self.x - gun_rect.center[0], self.y - gun_rect.center[1]))

    def shot(self, enemies):
        shot_range = 180 + self.level * 45
        damage = 1.5 + 0.5 * self.level + float(1 * int(global_levels_list[0]) - 1)

        in_range_enemies_list = []

        for enemy in enemies:
            if -shot_range <= math.sqrt((enemy.x - self.x) ** 2 + (enemy.y - self.y) ** 2) <= shot_range:

                in_range_enemies_list.append((enemy.x, enemy.y))
                in_range_enemies_list.sort()

        self.shot_count += 1

        if len(in_range_enemies_list) != 0:
            if self.shot_count >= 5:
                pygame.draw.line(self.surface, pygame.Color(237, 166, 43), (self.x, self.y), (in_range_enemies_list[0][0], in_range_enemies_list[0][1]))
                for enemy in enemies:
                    if enemy.x == in_range_enemies_list[0][0] and enemy.y == in_range_enemies_list[0][1]:
                        enemy.hp -= damage

        if self.shot_count >= 60:
            self.shot_count = 0


class Fire:

    def __init__(self, surface, x, y, level):
        self.surface = surface
        self.x = x
        self.y = y
        self.level = level
        self.shot_count = 0
        self.price = 250

    def draw(self, enemies):
        self.surface.blit(pygame.image.load("textures/fire_base.png").convert_alpha(), (self.x - 45, self.y - 45))

        shot_range = 135 + self.level * 22.5

        enemies_coords_list = []

        gun_image = pygame.transform.scale(pygame.image.load("textures/fire_gun_0.png").convert_alpha(), (100, 100))

        for enemy in enemies:
            if -shot_range <= math.sqrt((enemy.x - self.x) ** 2 + (enemy.y - self.y) ** 2) <= shot_range:

                enemies_coords_list.append((enemy.x - self.x, enemy.y - self.y))
                enemies_coords_list.sort()

                if str(enemy.y - self.y).startswith("-"):
                    gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/fire_gun{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), math.atan(enemies_coords_list[0][0] / enemies_coords_list[0][1]) * 180 / math.pi)


                elif int(enemies_coords_list[0][0]) == 0:
                    gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/fire_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), 90)


                elif int(enemies_coords_list[0][1]) == 0:
                    gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/fire_gun_{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), 0)

                else:
                    gun_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(f"textures/fire_gun{math.floor(self.shot_count / 5)}.png").convert_alpha(), (100, 100)), math.atan(enemies_coords_list[0][0] / enemies_coords_list[0][1]) * 180 / math.pi + 180)

        gun_rect = gun_image.get_rect()

        self.surface.blit(gun_image, (self.x - gun_rect.center[0], self.y - gun_rect.center[1]))

    def shot(self, enemies):
        shot_range = 135 + self.level * 22.5
        damage = 1.5 + 0.5 * self.level + float(1 * int(global_levels_list[0]) - 1)

        in_range_enemies_list = []

        for enemy in enemies:
            if -shot_range <= math.sqrt((enemy.x - self.x) ** 2 + (enemy.y - self.y) ** 2) <= shot_range:

                in_range_enemies_list.append((enemy.x, enemy.y))
                in_range_enemies_list.sort()

        self.shot_count += 1

        if len(in_range_enemies_list) != 0:
            if self.shot_count >= 5:
                pygame.draw.line(self.surface, pygame.Color(237, 166, 43), (self.x, self.y), (in_range_enemies_list[0][0], in_range_enemies_list[0][1]))
                for enemy in enemies:
                    if enemy.x == in_range_enemies_list[0][0] and enemy.y == in_range_enemies_list[0][1]:
                        enemy.hp -= damage

        if self.shot_count >= 60:
            self.shot_count = 0
